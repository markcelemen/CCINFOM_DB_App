const mysql = require('mysql2');

// Create a connection pool
const pool = mysql.createPool({
  host: 'localhost',    // MySQL host
  user: 'root',         // Your MySQL username
  password: 'Bjrm6221!', // Your MySQL password
  database: 'RestaurantManagementSystem' // Your database name
});

// Export the pool for use in other files
module.exports = pool.promise();
