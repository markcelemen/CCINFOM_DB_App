const express = require('express');
const { create } = require('express-handlebars'); // Updated for express-handlebars v6+
const bodyParser = require('body-parser');
const db = require('./db'); // Import the database connection
const path = require('path');

const app = express();

// Set up body-parser to handle form data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Serve static files (if needed)
app.use(express.static('public'));

// Set up Handlebars view engine
const hbs = create({
  extname: '.hbs',
  defaultLayout: 'main', // Default layout file (e.g., main.hbs)
  layoutsDir: path.join(__dirname, '../frontend'), // Path to layouts directory
});

app.engine('hbs', hbs.engine);
app.set('view engine', 'hbs');

// Set the views directory to the frontend/views folder
app.set('views', path.join(__dirname, '../frontend'));

// Routes
app.get('/', async(req, res) => {
    res.render('main_menu');
});

app.get('/rec/home', async(req, res) => {
    res.render('records/menu');
});

app.get('/rec/menuitem', async (req, res) => {
    try {
      // Example database query (update the query based on your schema)
      const [rows] = await db.query('SELECT * FROM menuitem');
      res.render('records/menuitem', { data: rows }); // Pass the query result to the template
    } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
    }
  });

app.get('/rec/menuitem_filter', async (req, res) => {
    const itemId = req.query['Item ID'];
    const itemName = req.query['Item Name'];
    const price = req.query['Price'];
    const category = req.query['Category'];
    const inventory = req.query['Inventory'];

    let sql = 'SELECT * FROM menuitem WHERE 1=1'; 
    const params = [];

    if (itemId) {
        sql += ' AND item_id = ?';
        params.push(itemId);
    }
    if (itemName) {
        sql += ' AND item_name LIKE ?';
        params.push(`%${itemName}%`);
    }
    if (price) {
        sql += ' AND price = ?';
        params.push(price);
    }
    if (category != 'None') {
        sql += ' AND category = ?';
        params.push(category);
    }
    if (inventory) {
        sql += ' AND inventory = ?';
        params.push(inventory);
    }

    try {
        const [rows] = await db.query(sql, params);
        res.render('records/menuitem', { data: rows});
    } catch (error) {
        console.error(error);
        res.status(500).send('Database query failed');
    }
  });

app.get('/rec/orders', async (req, res) => {
    try {
      // Example database query (update the query based on your schema)
      const [rows] = await db.query('SELECT * FROM orders');
      res.render('records/orders', { data: rows }); // Pass the query result to the template
    } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
    }
  });

app.get('/rec/orders_filter', async (req, res) => {
    const orderId = req.query['Order ID'];
    const customerId = req.query['Customer ID'];
    const employeeId = req.query['Employee ID'];
    const orderDate = req.query['Order Date'];
    const totalAmount = req.query['Total Amount'];

    let sql = 'SELECT * FROM orders WHERE 1=1'; 
    const params = [];

    if (orderId) {
        sql += ' AND order_id = ?';
        params.push(orderId);
    }
    if (customerId) {
        sql += ' AND customer_id = ?';
        params.push(customerId);
    }
    if (employeeId) {
        sql += ' AND employee_id = ?';
        params.push(employeeId);
    }
    if (orderDate) {
        sql += ' AND order_date = ?';
        params.push(orderDate);
    }
    if (totalAmount) {
        sql += ' AND total_amount = ?';
        params.push(totalAmount);
    }

    try {
        const [rows] = await db.query(sql, params);
        res.render('records/orders', { data: rows });
    } catch (error) {
        console.error(error);
        res.status(500).send('Database query failed');
    }
  });

app.get('/rec/employee', async (req, res) => {
    try {
      // Example database query (update the query based on your schema)
      const [rows] = await db.query('SELECT * FROM employee');
      res.render('records/employee', { data: rows }); // Pass the query result to the template
    } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
    }
  });

app.get('/rec/employee_filter', async (req, res) => {
    const employeeId = req.query['Employee ID'];
    const lastName = req.query['Last Name'];
    const firstName = req.query['First Name'];
    const position = req.query['Position'];
    const salary = req.query['Salary'];

    let sql = 'SELECT * FROM employee WHERE 1=1'; 
    const params = [];

    if (employeeId) {
        sql += ' AND employee_id = ?';
        params.push(employeeId);
    }
    if (lastName) {
        sql += ' AND last_name LIKE ?';
        params.push(`%${lastName}%`);
    }
    if (firstName) {
        sql += ' AND first_name LIKE ?';
        params.push(`%${firstName}%`);
    }
    if (position) {
        sql += ' AND position LIKE ?';
        params.push(`%${position}%`);
    }
    if (salary) {
        sql += ' AND salary = ?';
        params.push(salary);
    }

    try {
        const [rows] = await db.query(sql, params);
        res.render('records/employee', { data: rows });
    } catch (error) {
        console.error(error);
        res.status(500).send('Database query failed');
    }
});

app.get('/rec/customer', async (req, res) => {
  try {
    // Example database query (update the query based on your schema)
    const [rows] = await db.query('SELECT * FROM customer');
    res.render('records/customer', { data: rows }); // Pass the query result to the template
  } catch (error) {
    console.error(error);
    res.status(500).send('Database query failed');
  }
});

app.get('/rec/customer_filter', async (req, res) => {
  const customerId = req.query['Customer ID'];
  const lastName = req.query['Last Name'];
  const firstName = req.query['First Name'];
  const contactInfo = req.query['Contact Info'];

  let sql = 'SELECT * FROM customer WHERE 1=1'; 
  const params = [];

  if (customerId) {
      sql += ' AND customer_id = ?';
      params.push(customerId);
  }
  if (lastName) {
      sql += ' AND last_name LIKE ?';
      params.push(`%${lastName}%`);
  }
  if (firstName) {
      sql += ' AND first_name LIKE ?';
      params.push(`%${firstName}%`);
  }
  if (contactInfo) {
      sql += ' AND contact_info LIKE ?';
      params.push(`%${contactInfo}%`);
  }

  try {
      const [rows] = await db.query(sql, params);
      res.render('records/customer', { data: rows });
  } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
  }
});

app.get('/rec/orderitem', async (req, res) => {
  try {
    // Example database query (update the query based on your schema)
    const [rows] = await db.query('SELECT * FROM orderitem');
    res.render('records/orderitem', { data: rows }); // Pass the query result to the template
  } catch (error) {
    console.error(error);
    res.status(500).send('Database query failed');
  }
});

app.get('/rec/orderitem_filter', async (req, res) => {
  const orderId = req.query['Order ID'];
  const itemId = req.query['Item ID'];
  const quantity = req.query['Quantity'];
  const itemPrice = req.query['Item Price'];

  let sql = 'SELECT * FROM orderitem WHERE 1=1'; 
  const params = [];

  if (orderId) {
      sql += ' AND order_id = ?';
      params.push(orderId);
  }
  if (itemId) {
      sql += ' AND item_id = ?';
      params.push(itemId);
  }
  if (quantity) {
      sql += ' AND quantity = ?';
      params.push(quantity);
  }
  if (itemPrice) {
      sql += ' AND item_price = ?';
      params.push(itemPrice);
  }

  try {
      const [rows] = await db.query(sql, params);
      res.render('records/orderitem', { data: rows });
  } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
  }
});



// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});