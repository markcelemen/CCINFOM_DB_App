const express = require('express');
const { create } = require('express-handlebars'); // Updated for express-handlebars v6+
const bodyParser = require('body-parser');
const db = require('./db'); // Import the database connection
const path = require('path');

const app = express();

// Set up body-parser to handle form data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Serve static files (if needed)
app.use(express.static('public'));

// Set up Handlebars view engine
const hbs = create({
  extname: '.hbs',
  defaultLayout: 'main', // Default layout file (e.g., main.hbs)
  layoutsDir: path.join(__dirname, '../frontend'), // Path to layouts directory
});

app.engine('hbs', hbs.engine);
app.set('view engine', 'hbs');

// Set the views directory to the frontend/views folder
app.set('views', path.join(__dirname, '../frontend'));

// Routes
app.get('/', async(req, res) => {
    res.render('main_menu');
});

app.get('/rec/home', async(req, res) => {
    res.render('records/menu');
});

app.get('/rec/menuitem', async (req, res) => {
    try {
      // Example database query (update the query based on your schema)
      const [rows] = await db.query('SELECT * FROM menuitem');
      res.render('records/menuitem', { data: rows }); // Pass the query result to the template
    } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
    }
  });

app.get('/rec/menuitem_filter', async (req, res) => {
    const itemId = req.query['Item ID'];
    const itemName = req.query['Item Name'];
    const price = req.query['Price'];
    const category = req.query['Category'];
    const inventory = req.query['Inventory'];

    let sql = 'SELECT * FROM menuitem WHERE 1=1'; 
    const params = [];

    if (itemId) {
        sql += ' AND item_id = ?';
        params.push(itemId);
    }
    if (itemName) {
        sql += ' AND item_name LIKE ?';
        params.push(`%${itemName}%`);
    }
    if (price) {
        sql += ' AND price = ?';
        params.push(price);
    }
    if (category != 'None') {
        sql += ' AND category = ?';
        params.push(category);
    }
    if (inventory) {
        sql += ' AND inventory = ?';
        params.push(inventory);
    }

    try {
        const [rows] = await db.query(sql, params);
        res.render('records/menuitem', { data: rows});
    } catch (error) {
        console.error(error);
        res.status(500).send('Database query failed');
    }
  });

app.get('/rec/orders', async (req, res) => {
    try {
      // Example database query (update the query based on your schema)
      const [rows] = await db.query('SELECT * FROM orders');
      res.render('records/orders', { data: rows }); // Pass the query result to the template
    } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
    }
  });

app.get('/rec/orders_filter', async (req, res) => {
    const orderId = req.query['Order ID'];
    const customerId = req.query['Customer ID'];
    const employeeId = req.query['Employee ID'];
    const orderDate = req.query['Order Date'];
    const totalAmount = req.query['Total Amount'];

    let sql = 'SELECT * FROM orders WHERE 1=1'; 
    const params = [];

    if (orderId) {
        sql += ' AND order_id = ?';
        params.push(orderId);
    }
    if (customerId) {
        sql += ' AND customer_id = ?';
        params.push(customerId);
    }
    if (employeeId) {
        sql += ' AND employee_id = ?';
        params.push(employeeId);
    }
    if (orderDate) {
        sql += ' AND order_date = ?';
        params.push(orderDate);
    }
    if (totalAmount) {
        sql += ' AND total_amount = ?';
        params.push(totalAmount);
    }

    try {
        const [rows] = await db.query(sql, params);
        res.render('records/orders', { data: rows });
    } catch (error) {
        console.error(error);
        res.status(500).send('Database query failed');
    }
  });

app.get('/rec/employee', async (req, res) => {
    try {
      // Example database query (update the query based on your schema)
      const [rows] = await db.query('SELECT * FROM employee');
      res.render('records/employee', { data: rows }); // Pass the query result to the template
    } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
    }
  });

app.get('/rec/employee_filter', async (req, res) => {
    const employeeId = req.query['Employee ID'];
    const lastName = req.query['Last Name'];
    const firstName = req.query['First Name'];
    const position = req.query['Position'];
    const salary = req.query['Salary'];

    let sql = 'SELECT * FROM employee WHERE 1=1'; 
    const params = [];

    if (employeeId) {
        sql += ' AND employee_id = ?';
        params.push(employeeId);
    }
    if (lastName) {
        sql += ' AND last_name LIKE ?';
        params.push(`%${lastName}%`);
    }
    if (firstName) {
        sql += ' AND first_name LIKE ?';
        params.push(`%${firstName}%`);
    }
    if (position) {
        sql += ' AND position LIKE ?';
        params.push(`%${position}%`);
    }
    if (salary) {
        sql += ' AND salary = ?';
        params.push(salary);
    }

    try {
        const [rows] = await db.query(sql, params);
        res.render('records/employee', { data: rows });
    } catch (error) {
        console.error(error);
        res.status(500).send('Database query failed');
    }
});

app.get('/rec/customer', async (req, res) => {
  try {
    // Example database query (update the query based on your schema)
    const [rows] = await db.query('SELECT * FROM customer');
    res.render('records/customer', { data: rows }); // Pass the query result to the template
  } catch (error) {
    console.error(error);
    res.status(500).send('Database query failed');
  }
});

app.get('/rec/customer_filter', async (req, res) => {
  const customerId = req.query['Customer ID'];
  const lastName = req.query['Last Name'];
  const firstName = req.query['First Name'];
  const contactInfo = req.query['Contact Info'];

  let sql = 'SELECT * FROM customer WHERE 1=1'; 
  const params = [];

  if (customerId) {
      sql += ' AND customer_id = ?';
      params.push(customerId);
  }
  if (lastName) {
      sql += ' AND last_name LIKE ?';
      params.push(`%${lastName}%`);
  }
  if (firstName) {
      sql += ' AND first_name LIKE ?';
      params.push(`%${firstName}%`);
  }
  if (contactInfo) {
      sql += ' AND contact_info LIKE ?';
      params.push(`%${contactInfo}%`);
  }

  try {
      const [rows] = await db.query(sql, params);
      res.render('records/customer', { data: rows });
  } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
  }
});

app.get('/rec/orderitem', async (req, res) => {
  try {
    // Example database query (update the query based on your schema)
    const [rows] = await db.query('SELECT * FROM orderitem');
    res.render('records/orderitem', { data: rows }); // Pass the query result to the template
  } catch (error) {
    console.error(error);
    res.status(500).send('Database query failed');
  }
});

app.get('/rec/orderitem_filter', async (req, res) => {
  const orderId = req.query['Order ID'];
  const itemId = req.query['Item ID'];
  const quantity = req.query['Quantity'];
  const itemPrice = req.query['Item Price'];

  let sql = 'SELECT * FROM orderitem WHERE 1=1'; 
  const params = [];

  if (orderId) {
      sql += ' AND order_id = ?';
      params.push(orderId);
  }
  if (itemId) {
      sql += ' AND item_id = ?';
      params.push(itemId);
  }
  if (quantity) {
      sql += ' AND quantity = ?';
      params.push(quantity);
  }
  if (itemPrice) {
      sql += ' AND item_price = ?';
      params.push(itemPrice);
  }

  try {
      const [rows] = await db.query(sql, params);
      res.render('records/orderitem', { data: rows });
  } catch (error) {
      console.error(error);
      res.status(500).send('Database query failed');
  }
});

app.get('/tra/home', async(req, res) => {
  res.render('transactions/menu');
});

app.get('/tra/placeOrder', async(req, res) => {
  try {
    const [customers] = await db.query('SELECT * FROM Customer ORDER BY customer_id ASC');
    res.render('transactions/placeorder', {
      customers,
      notVerified: true
    })
  } catch(err) {
    console.error('Error fetching menu items:', err);
    res.status(500).send('Database query failed');
  }
  /*
  res.render('transactions/placeorder', {
      notVerified: true
    })
  */
});

// const { customer_id } = req.query;
app.get('/tra/placeOrder/customer', async (req, res) => {
  const { customer_id } = req.query;
  try {
      const [customerRows] = await db.query('SELECT * FROM customer WHERE customer_id = ?', [customer_id]);
      if (customerRows.length > 0) {
          const [menuItems] = await db.query('SELECT * FROM menuitem ORDER BY item_name ASC');
          res.render('transactions/placeorder', {
              customer: customerRows[0],
              menuItems,
              notVerified: false
          });
      } else {
          res.render('transactions/placeorder', { error: 'Customer not found' });
      }
  } catch (err) {
      console.error(err);
      res.status(500).send('Database query failed');
  }
});

app.post('/tra/placeOrder/addItems', async (req, res) => {
  // Ensure items[] is always an array
  const items = Array.isArray(req.body['items[]']) ? req.body['items[]'] : [req.body['items[]']];

  if (items.length === 0) {
    return res.status(400).send('No items selected');
  }

  const customerId = req.body.customer_id;

  // Extract the quantities for each item based on the item_id
  const quantities = items.map(id => ({
    item_id: id,
    quantity: parseInt(req.body[`quantity_${id}`], 10) || 1, // Default to 1 if no quantity specified
  }));

  try {
    // Fetch the menu items from the database
    const placeholders = items.map(() => '?').join(','); // Prepare for parameterized query
    const [menuRows] = await db.query(
      `SELECT * FROM menuitem WHERE item_id IN (${placeholders})`,
      items // Pass item IDs as query parameters
    );

    // Combine menu item data with quantities
    const orderItems = menuRows.map(item => {
      const quantityObj = quantities.find(q => q.item_id == item.item_id);
      return {
        ...item,
        quantity: quantityObj ? quantityObj.quantity : 0,
      };
    });

    // Calculate total amount
    const totalAmount = orderItems.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );

    res.render('transactions/placeorder', {
      order: {
        customer_id: customerId,
        items: orderItems,
        total_amount: totalAmount,
      },
    });
  } catch (err) {
    console.error('Error processing order:', err);
    res.status(500).send('Error processing order');
  }
});

app.post('/tra/placeOrder/confirm', async (req, res) => {
  // const { customer_id, orderItems, total_amount } = req.body; // `orderItems` should contain selected item IDs and quantities.
  const customer_id = req.body.customer_id;
  const total_amount = req.body.total_amount;
  const orderItems = Array.isArray(req.body['item_id']) ? req.body['item_id'] : [req.body['item_id']];

  const quantities = orderItems.map(id => ({
    item_id: id,
    quantity: parseInt(req.body[`quantity_${id}`], 10) || 1, // Default to 1 if no quantity specified
  }));

  try {
      // Step 1: Insert the order into the `Orders` table
      const today = new Date().toISOString().split('T')[0];
      const [orderResult] = await db.query('INSERT INTO Orders (customer_id, order_date, total_amount) VALUES (?, ?, ?)', [customer_id, today, total_amount]);
      const orderId = orderResult.insertId;

      // Step 2: Insert each item into the `OrderItem` table
      for (let i = 0; i < orderItems.length; i++) {
        const item_id = orderItems[i]; // item_id from orderItems
        const quantity = quantities[i].quantity; // quantity from quantities
    
        // Now insert each item with its quantity
        await db.query('INSERT INTO OrderItem (order_id, item_id, quantity, item_price) VALUES (?, ?, ?, (SELECT price FROM MenuItem WHERE item_id = ?))', 
        [orderId, item_id, quantity, item_id]);
    }

      // Step 3: Update the total amount in the `Orders` table
      await db.query(
          `UPDATE Orders
           SET total_amount = (
               SELECT SUM(m.price * oi.quantity)
               FROM OrderItem oi
               JOIN MenuItem m ON oi.item_id = m.item_id
               WHERE oi.order_id = ?
           )`,
          [orderId]
      );

      // Redirect to the transactions home page or a success page
      res.render('transactions/menu');
  } catch (error) {
      console.error('Error confirming order:', error);
      res.status(500).send('Error confirming order');
  }
});

app.get('/tra/updateMenuPrice', async(req, res) => {
  res.render('transactions/updatemenuprice');
});

app.get('/tra/changePrice', async(req, res) => {
  try {
    // Step 1: Fetch all menu items to display
    const [menuItems] = await db.query('SELECT * FROM menuitem ORDER BY item_id ASC');
    res.render('transactions/changeprice', {
      menuItems // Pass the menu items to the template for display
    });
  } catch (err) {
    console.error('Error fetching menu items:', err);
    res.status(500).send('Database query failed');
  }
});

app.post('/tra/changePrice', async (req, res) => {
  const { price, increaseType, itemId } = req.body;

  if (!price || !itemId) {
    return res.status(400).send('Price and Item ID are required.');
  }

  try {
    // Find the current price of the selected item
    const [rows] = await db.query('SELECT * FROM MenuItem WHERE item_id = ?', [itemId]);

    if (rows.length === 0) {
      return res.status(404).send('Item not found.');
    }

    let newPrice = parseFloat(rows[0].price); // Get the current price of the item
    let fixedAmount = parseFloat(price);  // Convert the fixed amount input into a number

    if (isNaN(fixedAmount)) {
      return res.status(400).send('Invalid fixed amount value.');
    }

    if (increaseType === 'increase') {
      // If it's an increase, add the fixed amount to the current price
      newPrice += fixedAmount;
    } else if (increaseType === 'decrease') {
      // If it's a decrease, subtract the fixed amount from the current price
      newPrice -= fixedAmount;
    }

    // Update the item with the new price
    await db.query('UPDATE MenuItem SET price = ? WHERE item_id = ?', [newPrice, itemId]);

    // Fetch the updated list of menu items
    const [menuItems] = await db.query('SELECT * FROM MenuItem ORDER BY item_name ASC');

    // Render the page with updated menu items
    res.render('transactions/updatemenuprice', {
      menuItems,
      successMessage: 'Price updated successfully.'
    });

  } catch (error) {
    console.error(error);
    res.status(500).send('Error updating the price.');
  }
});

app.get('/tra/addMenuItem', async (req, res) => {
  try {
      res.render('transactions/addmenuitem');
  } catch (err) {
      console.error(err);
      res.status(500).send('Error loading add menu item page');
  }
});

app.post('/tra/addMenuItem', async (req, res) => {
  const { item_name, description, price, category } = req.body;

  // Validate form fields
  if (!item_name || !description || !price || !category) {
      return res.status(400).send('All fields are required.');
  }

  // Insert new item into the MenuItem table
  try {
      await db.query(
          'INSERT INTO MenuItem(item_name, description, price, category) VALUES(?, ?, ?, ?)',
          [item_name, description, parseFloat(price), category]
      );

      // Redirect to the update menu page or back to the menu list with a success message
      res.render('transactions/updatemenuprice')
  } catch (err) {
      console.error('Error inserting menu item:', err);
      res.status(500).send('Error inserting menu item');
  }
});


app.get('/tra/deleteMenuItem', async (req, res) => {
  try {
    // Fetch all menu items to display on the deletion page
    const [menuItems] = await db.query('SELECT * FROM menuitem ORDER BY item_id ASC');
    res.render('transactions/deleteitem', {
      menuItems // Pass the list of menu items to the template
    });
  } catch (err) {
    console.error('Error fetching menu items:', err);
    res.status(500).send('Database query failed');
  }
});

app.post('/tra/deleteMenuItem', async (req, res) => {
  const { itemId } = req.body;

  if (!itemId) {
    return res.status(400).send('Item ID is required.');
  }

  try {
    // Delete the selected menu item from the database
    await db.query('DELETE FROM MenuItem WHERE item_id = ?', [itemId]);

    // Fetch the updated list of menu items
    const [menuItems] = await db.query('SELECT * FROM MenuItem ORDER BY item_name ASC');

    // Render the page with updated menu items
    res.render('transactions/updatemenuprice');

  } catch (error) {
    console.error('Error deleting the item:', error);
    res.status(500).send('Error deleting menu item');
  }
});

app.get('/tra/payrollMenu', async(req, res) => {
  res.render('transactions/payrollmenu');
});

app.get('/tra/payrollAdd', async(req, res) => {
  try {
    res.render('transactions/addpayroll');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error loading add menu item page');
  } 
});

app.post('/tra/payrollAdd', async(req, res) =>{
  const { last_name, first_name, position, salary } = req.body;

  if (!last_name|| !first_name || !position || !salary) {
    return res.status(400).send('All fields are required.');
  }

  try {
    await db.query(
      'INSERT INTO Employee(last_name, first_name, position, salary) VALUES (?, ?, ?, ?)',
      [last_name, first_name, position, salary]
    );
    res.render('transactions/payrollmenu')
  } catch(err) {
    console.error('Error inserting menu item:', err);
    res.status(500).send('Error inserting menu item');
  }
});

app.get('/tra/payrollDelete', async(req, res) => {
  try {
    // Fetch all menu items to display on the deletion page
    const [menuItems] = await db.query('SELECT * FROM Employee ORDER BY employee_id ASC');
    res.render('transactions/deletepayroll', {
      menuItems
    });
  } catch (err) {
    console.error('Error fetching menu items:', err);
    res.status(500).send('Database query failed');
  }
});

app.post('/tra/payrollDelete', async(req, res) => {
  const { employeeID } = req.body;

  if (!employeeID) {
    return res.status(400).send('Employee ID is required.');
  }

  try {
    // Delete the selected menu item from the database
    await db.query('DELETE FROM Employee WHERE employee_id = ?', [employeeID]);

    // Fetch the updated list of menu items
    const [menuItems] = await db.query('SELECT * FROM Employee ORDER BY employee_id ASC');

    // Render the page with updated menu items
    res.render('transactions/payrollmenu');

  } catch (error) {
    console.error('Error deleting the item:', error);
    res.status(500).send('Error deleting menu item');
  }
});

app.get('/tra/payrollUpdate', async(req, res) => {
  try {
    // Fetch all employees to populate the employee dropdown
    const [employees] = await db.query('SELECT * FROM employee ORDER BY employee_id');
    res.render('transactions/payrollupdate', {
      employees, // Pass the list of employees to the template
      successMessage: req.query.successMessage || null // Show success message if present
    });
  } catch (err) {
    console.error('Error fetching employees:', err);
    res.status(500).send('Database query failed');
  }
});

app.post('/tra/payrollUpdate', async (req, res) => {
  const { employee_id, position, percentage_increase } = req.body;

  // Validate form fields
  if (!employee_id || !position || !percentage_increase) {
    return res.status(400).send('All fields are required.');
  }

  // Convert percentage to decimal (e.g., 10% becomes 1.10)
  const increaseFactor = 1 + (parseFloat(percentage_increase) / 100);

  try {
    // Update the salary based on the position and employee ID
    await db.query(
      'UPDATE Employee SET salary = salary * ? WHERE position = ? AND employee_id = ?',
      [increaseFactor, position, employee_id]
    );

    // Redirect back to the payroll update page with a success message
    res.render('transactions/payrollmenu');
  } catch (err) {
    console.error('Error updating payroll:', err);
    res.status(500).send('Database query failed');
  }
});

app.get('/rep/home', async(req, res) => {
  res.render('reports/menu');
});

app.get('/rep/sales', async(req, res) => {
  res.render('reports/sales', {
    salesData: null
  });
});

app.post('/rep/sales', async (req, res) => {
  const { startDate, endDate, timePeriod } = req.body;  // Fetching date range and time period from the request body

  if (!startDate || !endDate || !timePeriod) {
      return res.status(400).send('Start date, end date, and time period are required');
  }

  // Adjust the SQL query based on the selected time period (Day, Month, or Year)
  let groupByClause;
  let selectDateClause;

  if (timePeriod === 'Day') {
    groupByClause = 'o.order_date';  // Group by the exact order date
    selectDateClause = 'o.order_date AS date';
  } else if (timePeriod === 'Month') {
    groupByClause = 'YEAR(o.order_date), MONTH(o.order_date)';  // Group by Year-Month
    selectDateClause = 'MONTH(o.order_date) AS date';  // Format as Year-Month
  } else if (timePeriod === 'Year') {
    groupByClause = 'YEAR(o.order_date)';  // Group by the year
    selectDateClause = 'YEAR(o.order_date) AS date';  // Extract only the year
  }

  const sql = `
      SELECT
          m.item_name,
          ${selectDateClause},
          SUM(oi.quantity) AS total_quantity_sold,
          SUM(oi.quantity * oi.item_price) AS total_sales
      FROM
          OrderItem oi
      JOIN
          MenuItem m ON oi.item_id = m.item_id
      JOIN
          Orders o ON oi.order_id = o.order_id
      WHERE
          o.order_date BETWEEN ? AND ?
      GROUP BY
          m.item_name, ${groupByClause}
      ORDER BY
          total_sales DESC;
  `;

  try {
      const [rows] = await db.query(sql, [startDate, endDate]);

      res.render('reports/sales', {
          salesData: rows,
          startDate,
          endDate,
          timePeriod  // Pass the selected time period to the view
      });
  } catch (error) {
      console.error('Error fetching sales data:', error);
      res.status(500).send('Database query failed');
  }
  /*
  const { startDate, endDate } = req.body;

  if (!startDate || !endDate) {
      return res.status(400).send('Start date and end date are required');
  }

  const sql = `
      SELECT
          m.item_name,
          SUM(oi.quantity) AS total_quantity_sold,
          SUM(oi.quantity * oi.item_price) AS total_sales
      FROM
          OrderItem oi
      JOIN
          MenuItem m ON oi.item_id = m.item_id
      JOIN
          Orders o ON oi.order_id = o.order_id
      WHERE
          o.order_date BETWEEN ? AND ?  -- Placeholder for date range
      GROUP BY
          m.item_name
      ORDER BY
          total_sales DESC;
  `;

  try {
      const [rows] = await db.query(sql, [startDate, endDate]);

      res.render('reports/sales', {
          salesData: rows,
          startDate,
          endDate
      });
  } catch (error) {
      console.error('Error fetching sales data:', error);
      res.status(500).send('Database query failed');
  }
      */
});

app.get('/rep/topItems', (req, res) => {
  res.render('reports/topitems', {
    topItemsData: null
  });
});

app.post('/rep/topItems', async (req, res) => {
  const { startDate, endDate, timePeriod } = req.body;  // Fetching date range and time period from the request body

  if (!startDate || !endDate || !timePeriod) {
      return res.status(400).send('Start date, end date, and time period are required');
  }

  // Adjust the SQL query based on the selected time period (Day, Month, or Year)
  let groupByClause;
  let selectDateClause;

  if (timePeriod === 'Day') {
    groupByClause = 'o.order_date';  // Group by the exact order date
    selectDateClause = 'o.order_date AS date';
  } else if (timePeriod === 'Month') {
    groupByClause = 'YEAR(o.order_date), MONTH(o.order_date)';  // Group by Year-Month
    selectDateClause = 'MONTH(o.order_date) AS date';
  } else if (timePeriod === 'Year') {
    groupByClause = 'YEAR(o.order_date)';  // Group by the year
    selectDateClause = 'YEAR(o.order_date) AS date';  // Extract only the year
  }

  const sql = `
      SELECT
          mi.item_id,
          mi.item_name,
          ${selectDateClause},
          SUM(oi.quantity) AS total_quantity_sold,
          SUM(oi.quantity * oi.item_price) AS total_sales
      FROM
          OrderItem oi
      JOIN
          MenuItem mi ON oi.item_id = mi.item_id
      JOIN
          Orders o ON oi.order_id = o.order_id
      WHERE
          o.order_date BETWEEN ? AND ?
      GROUP BY
          mi.item_id, mi.item_name, ${groupByClause}
      ORDER BY
          total_sales DESC
      LIMIT 10;  -- Limit to the top 10 selling items
  `;

  try {
      const [rows] = await db.query(sql, [startDate, endDate]);

      res.render('reports/topitems', {
          topItemsData: rows,
          startDate,
          endDate,
          timePeriod  // Pass the selected time period to the view
      });
  } catch (error) {
      console.error('Error fetching top-selling items:', error);
      res.status(500).send('Database query failed');
  }
  /*
  const { startDate, endDate } = req.body;

  if (!startDate || !endDate) {
      return res.status(400).send('Start date and end date are required');
  }

  const sql = `
      SELECT
          mi.item_id,
          mi.item_name,
          SUM(oi.quantity) AS total_quantity_sold,
          SUM(oi.quantity * oi.item_price) AS total_sales
      FROM
          OrderItem oi
      JOIN
          MenuItem mi ON oi.item_id = mi.item_id
      JOIN
          Orders o ON oi.order_id = o.order_id
      WHERE
          o.order_date BETWEEN ? AND ?  -- Placeholder for date range
      GROUP BY
          mi.item_id, mi.item_name
      ORDER BY
          total_sales DESC
      LIMIT 10;  -- Limit to the top 10 selling items
  `;

  try {
      const [rows] = await db.query(sql, [startDate, endDate]);

      res.render('reports/topitems', {
          topItemsData: rows,
          startDate,
          endDate
      });
  } catch (error) {
      console.error('Error fetching top-selling items:', error);
      res.status(500).send('Database query failed');
  }
      */
});

app.get('/rep/employeePerformance', async(req, res) => {
  res.render('reports/employeeperformance', {
    employeePerformanceData: null
  });
});

app.post('/rep/employeePerformance', async(req, res) => {
  const { startDate, endDate, timePeriod } = req.body;  // Fetching date range and time period from query params

  if (!startDate || !endDate || !timePeriod) {
    return res.status(400).send('Start date, end date, and time period are required');
  } 

  // Adjust the SQL query based on the selected time period (Day, Month, or Year)
  let groupByClause;
  let selectDateClause;

  if (timePeriod === 'Day') {
    groupByClause = 'o.order_date';
    selectDateClause = 'o.order_date AS date';
  } else if (timePeriod === 'Month') {
    groupByClause = 'YEAR(o.order_date), MONTH(o.order_date)';
    selectDateClause = 'MONTH(o.order_date) AS date'; 
    //selectDateClause = 'MONTH(o.order_date) AS month, YEAR(o.order_date) AS year';  // Format: Year-Month
  } else if (timePeriod === 'Year') {
    groupByClause = 'YEAR(o.order_date)';
    selectDateClause = 'YEAR(o.order_date) AS date';  // Just the year
  }

  // SQL query to fetch employee performance data
  const query = `
  SELECT
      e.employee_id,
      e.first_name,
      e.last_name,
      e.position,
      ${selectDateClause},
      COUNT(o.order_id) AS total_orders_handled,
      SUM(o.total_amount) AS total_sales_handled
  FROM
      Employee e
  JOIN Orders o ON e.employee_id = o.employee_id
  WHERE
      o.order_date BETWEEN ? AND ?
  GROUP BY
      e.employee_id, ${groupByClause}
  ORDER BY
      total_sales_handled DESC;
  `;

  try {
      // Run the query with date parameters
      const [rows] = await db.query(query, [startDate, endDate]);

      // Render the page with the query results
      res.render('reports/employeeperformance', {
          employeePerformanceData: rows,
          startDate,
          endDate,
          timePeriod
      });
  } catch (err) {
      console.error(err);
      res.status(500).send('An error occurred while fetching the data.');
  }
  /*
  const { startDate, endDate } = req.body;  // Fetching date range from query params

  if (!startDate || !endDate) {
    return res.status(400).send('Start date and end date are required');
  } 

  // SQL query to fetch employee performance data
  const query = `
  SELECT
      e.employee_id,
      e.first_name,
      e.last_name,
      e.position,
      o.order_date AS date,
      COUNT(o.order_id) AS total_orders_handled,
      SUM(o.total_amount) AS total_sales_handled
  FROM
      Employee e
  JOIN Orders o ON e.employee_id = o.employee_id
  WHERE
      o.order_date BETWEEN ? AND ?
  GROUP BY
      e.employee_id, o.order_date
  ORDER BY
      total_sales_handled DESC;
  `;

  try {
      // Run the query with date parameters
      const [rows] = await db.query(query, [startDate, endDate]);

      // Render the page with the query results
      res.render('reports/employeeperformance', {
          employeePerformanceData: rows,
          startDate,
          endDate
      });
  } catch (err) {
      console.error(err);
      res.status(500).send('An error occurred while fetching the data.');
  }
  */
});


// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});